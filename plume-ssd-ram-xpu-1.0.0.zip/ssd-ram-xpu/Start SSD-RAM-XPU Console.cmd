@echo off
rem Starts the Plume SSD-RAM-XPU Console on 127.0.0.1:8789 (cross-origin isolated, so Wasm threads
rem work) and opens it in your default browser. Edit NODE if your portable Node lives elsewhere.
setlocal
set "HERE=%~dp0"
set "NODE=C:\Users\russe\Desktop\bytefoundry-0.99.2-win64\node-v22.23.4-win-x64\node.exe"
if not exist "%NODE%" set "NODE=node"
start "Plume SSD-RAM-XPU server" /min "%NODE%" "%HERE%serve.mjs"
timeout /t 1 /nobreak >nul
start "" "http://127.0.0.1:8789/"
endlocal
