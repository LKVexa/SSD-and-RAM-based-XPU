# Changelog

## 1.0.0 — 2026-11-02 (first release, on the Plume XPU 1.3.0 engine)

- **Drive on the machine's own disk.** A frame stack of 512 KiB Byte20 frames in the browser's
  Origin Private File System, sized up to 90 % of the page's storage quota, laid out after the
  operator's note: ns1 SSD-RAM : ns2 frame stack : ns3 records + reserve = 1 : 6 : 1.
  Frames are striped over 1–16 channel files; each frame has two slots (out-of-place writes) and a
  64-byte record with its generation, the engine that wrote it and its SHA-256 digest.
- **In-storage XPUs.** Every channel worker owns its files and runs its own xpu.wasm, so a pass
  (BF1 then BF2) advances a frame without it leaving the worker; 160 bytes cross to the page.
- **Host XPU path** with a configurable queue depth and a live Little's-law readout, on Wasm (1 or
  N threads) or WebGPU; **cooperative mode** splits channels between the two paths using their
  measured rates.
- **Every read is verified** against the frame's record; host writes are range-checked (20-bit
  words). Passes can be stopped and resumed; formats can be stopped and resumed.
- **Path-independent stack root**: the same seed and steps give the same root whatever the path,
  engine, channel count or interruptions. Verify recomputes sample frames from their seed on another
  engine.
- **SSD-RAM tier (plane I):** ns1 as byte-addressable memory, CXL-style (4 KiB page cache with clock
  eviction + double-buffered 64-byte cacheline write log with a two-level index, after SkyByte) versus
  BAR-style (uncached). Every load is checked against a shadow copy; every touched word is read back
  from disk.
- **Model panel:** the note's 2 TiB drive (namespaces, Little's law, attention-near-storage ratio,
  cooperative split) beside the figures measured on this machine.
