// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 RUSSELL PHILIP SMITHSON
//
// SSD-RAM-XPU storage runtime for the Plume console.
//
// The drive is a directory of files in the browser's Origin Private File System (OPFS), which
// lives on the machine's own disk. It is organised after the three namespaces of the operator's
// note "SSD-RAM-XPU" (ns1 : ns2 : ns3+reserve = 1 : 6 : 1):
//
//   ns1  ns1.dat          byte-addressable SSD-RAM tier, served by the RAM controller worker
//                         (4 KiB page cache + double-buffered 64-byte cacheline write log)
//   ns2  chNN.dat         the frame stack, striped over N channel files, two slots per frame
//                         (out-of-place writes: generation g lives in slot g mod 2)
//   ns3  chNN.rec         one 64-byte record per frame (generation, engine, SHA-256 digest),
//                         written by the near-storage side; the rest of ns3 is left unallocated
//                         as reserve
//
// Every channel file is owned by one channel worker. Each channel worker also holds its own
// instance of the XPU (xpu.wasm), so a frame can be advanced without leaving the storage worker:
// the in-storage path. The host path reads frames out, runs them on a host engine (Wasm threads
// or WebGPU) and writes them back. Both paths write the same records, so the stack's root digest
// does not depend on which path, engine or channel count produced it.

export const SSD_FORMAT = "PLUME-SSD/1.0";
export const SSD_DIR = "plume-ssd-ram-xpu";
export const FRAME_WORDS = 131072, FRAME_BYTES = FRAME_WORDS * 4, REC_BYTES = 64, PAGE = 4096, LINE = 64;
export const REC_MAGIC = 0x31525350; // "PSR1"
export const ENGINE_CODES = { seed: 0, "storage-wasm-1t": 1, "wasm-1t": 2, "wasm-mt": 3, webgpu: 4 };
export const ENGINE_NAMES = ["seed (format)", "in-storage Wasm", "host Wasm · 1 thread", "host Wasm · threads", "host WebGPU"];
export const MAX_CHANNELS = 16, MAX_FRAMES = 0x7fffffff;

// ---------- shared pure functions (also injected verbatim into the workers) ----------
function frameSeed(seed, f) {
  let z = (seed + Math.imul(f + 1, 0x9e3779b9)) >>> 0;
  z = Math.imul(z ^ (z >>> 16), 0x85ebca6b) >>> 0;
  z = Math.imul(z ^ (z >>> 13), 0xc2b2ae35) >>> 0;
  return (z ^ (z >>> 16)) >>> 0;
}
// Generation 0 of a frame: 20-bit words, digit 0 alive with probability dens %.
function seedField(seed, dens, out) {
  let s = (seed >>> 0) ^ 0x9e3779b9; if (s === 0) s = 1;
  const r = () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s; };
  const f = out || new Uint32Array(131072);
  for (let i = 0; i < f.length; i++) { let v = r() & 0xffffe; if (r() % 100 < dens) v |= 1; f[i] = v; }
  return f;
}
const FRAME_PREFIX = "PLUME-SSD-FRAME/1.0\u0000";
// digest = SHA-256(prefix ‖ u32le frame ‖ u32le generation ‖ SHA-256(frame bytes))
async function frameDigest(f, gen, u8) {
  const inner = new Uint8Array(await crypto.subtle.digest("SHA-256", u8));
  const pre = new TextEncoder().encode(FRAME_PREFIX);
  const msg = new Uint8Array(pre.length + 8 + 32);
  msg.set(pre, 0); const dv = new DataView(msg.buffer);
  dv.setUint32(pre.length, f >>> 0, true); dv.setUint32(pre.length + 4, gen >>> 0, true); msg.set(inner, pre.length + 8);
  return new Uint8Array(await crypto.subtle.digest("SHA-256", msg));
}
// popcount of digit 0 over the 8 lanes, one byte per cell (0..8): the frame scope image
function thumbOf(words) {
  const t = new Uint8Array(16384);
  for (let c = 0; c < 16384; c++) { let n = 0; const b = c * 8; for (let k = 0; k < 8; k++) n += words[b + k] & 1; t[c] = n; }
  return t;
}
const hex = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, "0")).join("");
export { frameSeed, seedField, frameDigest, thumbOf, hex };

// root = SHA-256("PLUME-SSD-STACK/1.0\0" ‖ u32le F ‖ u32le gen ‖ u32le s1 ‖ u32le s2 ‖ digest_0 ‖ … ‖ digest_F-1)
export async function stackRoot(F, gen, s1, s2, digests) {
  const pre = new TextEncoder().encode("PLUME-SSD-STACK/1.0\u0000");
  const msg = new Uint8Array(pre.length + 16 + digests.length);
  msg.set(pre, 0); const dv = new DataView(msg.buffer);
  [F, gen, s1, s2].forEach((v, i) => dv.setUint32(pre.length + 4 * i, v >>> 0, true));
  msg.set(digests, pre.length + 16);
  return hex(new Uint8Array(await crypto.subtle.digest("SHA-256", msg)));
}
export const T20 = (x) => (x + ((x * x) % 1048576 | 5)) % 1048576; // Klimov–Shamir on Z/2^20

// ---------- worker plumbing shared by both worker kinds ----------
const PLUMBING = `
const port = (typeof self !== 'undefined' && typeof self.postMessage === 'function') ? self : require('worker_threads').parentPort;
const on = (fn) => port.addEventListener ? port.addEventListener('message', (e) => fn(e.data)) : port.on('message', fn);
const now = () => performance.now();
let chain = Promise.resolve();
// messages are handled strictly one after another, even across awaits
on((m) => { chain = chain.then(() => handle(m)).catch((e) => port.postMessage({ type: 'error', id: m && m.id, message: String(e && e.message || e) })); });
async function openFile(loc, name) {
  if (loc.node) {
    const fs = require('fs'), path = require('path'); const p = path.join(loc.node, name);
    const fd = fs.openSync(p, fs.existsSync(p) ? 'r+' : 'w+');
    return { read: (u8, at) => fs.readSync(fd, u8, 0, u8.byteLength, at), write: (u8, at) => fs.writeSync(fd, u8, 0, u8.byteLength, at),
      size: () => fs.fstatSync(fd).size, truncate: (n) => fs.ftruncateSync(fd, n), flush: () => fs.fsyncSync(fd), close: () => fs.closeSync(fd) };
  }
  let dir = await navigator.storage.getDirectory(); dir = await dir.getDirectoryHandle(loc.dir, { create: true });
  const fh = await dir.getFileHandle(name, { create: true }); const h = await fh.createSyncAccessHandle();
  return { read: (u8, at) => h.read(u8, { at }), write: (u8, at) => h.write(u8, { at }), size: () => h.getSize(),
    truncate: (n) => h.truncate(n), flush: () => h.flush(), close: () => h.close() };
}
function readFull(file, u8, at) { let got = 0; while (got < u8.byteLength) { const n = file.read(u8.subarray(got), at + got); if (!n) break; got += n; }
  if (got < u8.byteLength) u8.fill(0, got); return got; }
function writeFull(file, u8, at) { let put = 0; while (put < u8.byteLength) { const n = file.write(u8.subarray(put), at + put); if (!n) throw new Error('the disk accepted no bytes at offset ' + (at + put) + ' (is the storage quota full?)'); put += n; } }
`;

export const CHANNEL_SRC = `${PLUMBING}
const WORDS = ${FRAME_WORDS}, FB = ${FRAME_BYTES}, RB = ${REC_BYTES}, MAGIC = ${REC_MAGIC};
${frameSeed.toString()}
${seedField.toString()}
const FRAME_PREFIX = ${JSON.stringify(FRAME_PREFIX)};
${frameDigest.toString()}
${thumbOf.toString()}
let st = null;
const eq32 = (a, b) => { for (let i = 0; i < 32; i++) if (a[i] !== b[i]) return false; return true; };
function readRec(j) {
  const r = new Uint8Array(RB); readFull(st.rec, r, j * RB); const dv = new DataView(r.buffer);
  if (dv.getUint32(0, true) !== MAGIC) throw new Error('frame ' + (j * st.N + st.c) + ' has no record (the drive is not fully formatted)');
  const f = dv.getUint32(8, true); if (f !== j * st.N + st.c) throw new Error('record ' + j + ' of channel ' + st.c + ' names frame ' + f);
  return { gen: dv.getUint32(4, true), eng: r[12], digest: r.slice(16, 48) };
}
function writeRec(j, gen, eng, digest) {
  const r = new Uint8Array(RB), dv = new DataView(r.buffer);
  dv.setUint32(0, MAGIC, true); dv.setUint32(4, gen, true); dv.setUint32(8, j * st.N + st.c, true); r[12] = eng; r.set(digest, 16);
  writeFull(st.rec, r, j * RB);
}
const slotAt = (j, gen) => (2 * j + (gen & 1)) * FB;
// read the frame of record j into words and check it against its record: every read is verified
async function readChecked(j, words) {
  const rec = readRec(j), u8 = new Uint8Array(words.buffer, words.byteOffset, FB);
  const t0 = now(); readFull(st.dat, u8, slotAt(j, rec.gen)); const t1 = now();
  const d = await frameDigest(j * st.N + st.c, rec.gen, u8); const t2 = now();
  if (!eq32(d, rec.digest)) throw new Error('frame ' + (j * st.N + st.c) + ' (generation ' + rec.gen + ') does not match its stored digest');
  return { rec, read: t1 - t0, check: t2 - t1 };
}
function xpuRun(prog, input, steps) {
  const ex = st.ex, mem = () => ex.memory.buffer;
  if (!ex.configure(prog.p, prog.n, st.rule.birth, st.rule.survive)) throw new Error('the XPU refused ring Z/' + prog.p + '^' + prog.n);
  new Uint32Array(mem(), ex.prog_ptr(), prog.code.length).set(prog.code);
  if (!ex.load_program(prog.ninit, prog.nstep, prog.nfinal)) throw new Error('the XPU refused the program');
  new Uint32Array(mem(), ex.slot_ptr(0), WORDS).set(input);
  if (!ex.run(steps, 0, 1)) throw new Error('the XPU refused the run');
  return new Uint32Array(mem(), ex.slot_ptr(prog.outSlot), WORDS);
}
async function handle(m) {
  const reply = (o, tr) => port.postMessage({ id: m.id, type: 'done', ...o }, tr || []);
  switch (m.type) {
    case 'init': {
      const inst = await WebAssembly.instantiate(m.module, {});
      const c = m.c, N = m.N, F = m.F, J = F > c ? Math.floor((F - 1 - c) / N) + 1 : 0;
      st = { c, N, F, J, seed: m.seed, dens: m.dens, s1: m.s1, s2: m.s2, rule: m.rule, progs: m.progs, ex: (inst.instance || inst).exports, loc: m.loc,
        dat: await openFile(m.loc, 'ch' + String(c).padStart(2, '0') + '.dat'), rec: await openFile(m.loc, 'ch' + String(c).padStart(2, '0') + '.rec'),
        words: new Uint32Array(WORDS), since: 0 };
      return reply({ J });
    }
    case 'format': {
      const t0 = now();
      if (m.j0 === 0 && !m.resume) { st.rec.truncate(st.J * RB); st.dat.truncate(st.J * 2 * FB); }
      const u8 = new Uint8Array(st.words.buffer); let n = 0;
      for (let j = m.j0; j < m.j1; j++) {
        const f = j * st.N + st.c;
        if (m.resume) { let have = false; try { have = readRec(j).gen === 0; } catch { have = false; } if (have) { if (++n % 8 === 0) port.postMessage({ id: m.id, type: 'progress', n: 8 }); continue; } }
        seedField(frameSeed(st.seed, f), st.dens, st.words);
        writeFull(st.dat, u8, slotAt(j, 0)); writeRec(j, 0, 0, await frameDigest(f, 0, u8));
        if (++n % 8 === 0) port.postMessage({ id: m.id, type: 'progress', n: 8 });
      }
      if (n % 8) port.postMessage({ id: m.id, type: 'progress', n: n % 8 });
      st.dat.flush(); st.rec.flush();
      return reply({ ms: now() - t0 });
    }
    case 'compute': { // the in-storage path: the frame never leaves this worker
      const w = st.words; const r = await readChecked(m.j, w); const g = r.rec.gen;
      if (g !== m.gen) throw new Error('frame ' + (m.j * st.N + st.c) + ' is at generation ' + g + ', expected ' + m.gen);
      const t0 = now(); const o1 = xpuRun(st.progs[0], w, st.s1); w.set(o1); const o2 = xpuRun(st.progs[1], w, st.s2); w.set(o2); const t1 = now();
      const u8 = new Uint8Array(w.buffer); writeFull(st.dat, u8, slotAt(m.j, g + 1)); const t2 = now();
      const d = await frameDigest(m.j * st.N + st.c, g + 1, u8); writeRec(m.j, g + 1, 1, d); const t3 = now();
      if (++st.since % 16 === 0) { st.dat.flush(); st.rec.flush(); }
      const th = m.thumb ? thumbOf(w) : null;
      return reply({ f: m.j * st.N + st.c, gen: g + 1, digest: d, ms: { read: r.read, check: r.check, xpu: t1 - t0, write: t2 - t1, hash: t3 - t2 }, thumb: th }, th ? [th.buffer] : []);
    }
    case 'read': { // the host path: hand the verified frame out
      const w = new Uint32Array(WORDS); const r = await readChecked(m.j, w);
      if (r.rec.gen !== m.gen) throw new Error('frame ' + (m.j * st.N + st.c) + ' is at generation ' + r.rec.gen + ', expected ' + m.gen);
      return reply({ f: m.j * st.N + st.c, gen: r.rec.gen, buf: w, ms: { read: r.read, check: r.check } }, [w.buffer]);
    }
    case 'write': {
      const rec = readRec(m.j), w = m.buf;
      if (!(w instanceof Uint32Array) || w.length !== WORDS) throw new Error('a frame is ' + WORDS + ' words');
      if (m.gen !== rec.gen + 1) throw new Error('frame ' + (m.j * st.N + st.c) + ' write of generation ' + m.gen + ' onto generation ' + rec.gen);
      for (let i = 0; i < WORDS; i++) if (w[i] > 0xfffff) throw new Error('word ' + i + ' of frame ' + (m.j * st.N + st.c) + ' has bits above bit 19');
      const u8 = new Uint8Array(w.buffer, w.byteOffset, FB); const t0 = now(); writeFull(st.dat, u8, slotAt(m.j, m.gen)); const t1 = now();
      const d = await frameDigest(m.j * st.N + st.c, m.gen, u8); writeRec(m.j, m.gen, m.eng, d); const t2 = now();
      if (++st.since % 16 === 0) { st.dat.flush(); st.rec.flush(); }
      return reply({ f: m.j * st.N + st.c, gen: m.gen, digest: d, ms: { write: t1 - t0, hash: t2 - t1 } });
    }
    case 'scan': {
      const all = new Uint8Array(st.J * RB); readFull(st.rec, all, 0); const dv = new DataView(all.buffer);
      const gens = new Uint32Array(st.J), engs = new Uint8Array(st.J), digs = new Uint8Array(st.J * 32); let bad = 0;
      for (let j = 0; j < st.J; j++) {
        if (dv.getUint32(j * RB, true) !== MAGIC || dv.getUint32(j * RB + 8, true) !== j * st.N + st.c) { bad++; gens[j] = 0xffffffff; continue; }
        gens[j] = dv.getUint32(j * RB + 4, true); engs[j] = all[j * RB + 12]; digs.set(all.subarray(j * RB + 16, j * RB + 48), j * 32);
      }
      return reply({ gens, engs, digs, bad }, [gens.buffer, engs.buffer, digs.buffer]);
    }
    case 'putText': { const fh = await openFile(st.loc, m.name); const b = new TextEncoder().encode(m.text); fh.truncate(0); writeFull(fh, b, 0); fh.flush(); fh.close(); return reply({}); }
    case 'flush': st.dat.flush(); st.rec.flush(); return reply({});
    case 'close': if (st) { st.dat.flush(); st.rec.flush(); st.dat.close(); st.rec.close(); st = null; } return reply({});
    default: throw new Error('unknown request ' + m.type);
  }
}
`;

// ---------- the RAM controller: ns1 as byte-addressable memory ----------
// CXL-style mode (after SkyByte): a 4 KiB page data cache with clock eviction, and a double-buffered
// 64-byte cacheline write log with a two-level index (page → line → log slot). Stores append to the
// log and never read-modify-write a flash page; compaction coalesces the logged lines page by page.
// BAR-style mode: no cache, every load and store goes to the file at its exact address.
// The workload is a "plume" of point updates: load a 20-bit word, apply the BF1 T-function
// x ← x + (x² ∨ 5) mod 2^20, store it. Every load is checked against a shadow copy of what was
// stored, and after the run every touched word is read back from the file, bypassing the cache.
export const RAM_SRC = `${PLUMBING}
const PAGE = ${PAGE}, LINE = ${LINE};
const T20 = ${T20.toString()};
let st = null;
async function handle(m) {
  const reply = (o) => port.postMessage({ id: m.id, type: 'done', ...o });
  switch (m.type) {
    case 'init': st = { file: await openFile(m.loc, 'ns1.dat'), bytes: m.bytes }; if (st.file.size() !== m.bytes) st.file.truncate(m.bytes); return reply({});
    case 'workload': return reply(await workload(m));
    case 'bench': return reply(bench(m));
    case 'close': if (st) { st.file.flush(); st.file.close(); st = null; } return reply({});
    default: throw new Error('unknown request ' + m.type);
  }
}
function rng32(seed) { let s = (seed >>> 0) || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s; }; }
// latency of the medium as this browser sees it, from aggregate timings (the clock may be coarse)
function bench(m) {
  const f = st.file, pages = Math.floor(st.bytes / PAGE), r = rng32(m.seed || 99), n = m.n || 2048;
  const pg = new Uint8Array(PAGE), ln = new Uint8Array(LINE);
  let t0 = now(); for (let i = 0; i < n; i++) readFull(f, pg, (r() % pages) * PAGE); const p4k = (now() - t0) / n;
  t0 = now(); for (let i = 0; i < n; i++) readFull(f, ln, (r() % pages) * PAGE + (r() % 64) * LINE); const p64 = (now() - t0) / n;
  return { page4kUs: p4k * 1000, line64Us: p64 * 1000, n };
}
async function workload(m) {
  const f = st.file, W = Math.floor(st.bytes / 4), r = rng32(m.seed), inv = 1 / m.alpha, cxl = m.mode === 'cxl';
  // TRIM: every run starts from a zeroed namespace, so the shadow copy starts at zero too
  f.truncate(0); f.truncate(st.bytes);
  const s = { ops: 0, loads: 0, stores: 0, logHits: 0, cacheHits: 0, misses: 0, pagesRead: 0, pagesWritten: 0, devReads: 0, devWrites: 0,
    compactions: 0, compactMs: 0, readErrors: 0, verified: 0, verifyErrors: 0, loopMs: 0, verifyMs: 0 };
  const shadow = new Map();
  // ---- CXL-style structures ----
  const CP = m.cachePages, cbuf = new Uint8Array(CP * PAGE), cdv = new DataView(cbuf.buffer), ckey = new Float64Array(CP).fill(-1), cref = new Uint8Array(CP);
  const cmap = new Map(); let hand = 0;
  const mkLog = () => ({ data: new Uint8Array(m.logLines * LINE), n: 0, idx: new Map() });
  let act = mkLog(), frz = mkLog();
  const pg = new Uint8Array(PAGE);
  const logFind = (L, lpa, off) => { const l2 = L.idx.get(lpa); return l2 === undefined ? undefined : l2.get(off); };
  function cacheFill(lpa) { // flash → data cache, then lay the logged lines over it
    while (cref[hand]) { cref[hand] = 0; hand = (hand + 1) % CP; }
    const slot = hand; hand = (hand + 1) % CP;
    if (ckey[slot] >= 0) cmap.delete(ckey[slot]);
    readFull(f, cbuf.subarray(slot * PAGE, slot * PAGE + PAGE), lpa * PAGE); s.pagesRead++;
    for (const L of [frz, act]) { const l2 = L.idx.get(lpa); if (l2) for (const [off, ls] of l2) cbuf.set(L.data.subarray(ls * LINE, ls * LINE + LINE), slot * PAGE + off * LINE); }
    ckey[slot] = lpa; cref[slot] = 1; cmap.set(lpa, slot); return slot;
  }
  function compact(L) { // write every page with logged lines once, whatever the number of lines
    if (!L.n) return; const t0 = now();
    for (const [lpa, l2] of L.idx) {
      const slot = cmap.get(lpa);
      if (slot !== undefined) pg.set(cbuf.subarray(slot * PAGE, slot * PAGE + PAGE));
      else { readFull(f, pg, lpa * PAGE); s.pagesRead++; for (const [off, ls] of l2) pg.set(L.data.subarray(ls * LINE, ls * LINE + LINE), off * LINE); }
      writeFull(f, pg, lpa * PAGE); s.pagesWritten++;
    }
    L.idx.clear(); L.n = 0; s.compactions++; s.compactMs += now() - t0;
  }
  function load(addr) {
    const lpa = Math.floor(addr / PAGE), inpg = addr - lpa * PAGE, off = inpg >> 6, w = inpg & 63; let ls;
    if ((ls = logFind(act, lpa, off)) !== undefined) { s.logHits++; return new DataView(act.data.buffer).getUint32(ls * LINE + w, true); }
    if ((ls = logFind(frz, lpa, off)) !== undefined) { s.logHits++; return new DataView(frz.data.buffer).getUint32(ls * LINE + w, true); }
    let slot = cmap.get(lpa);
    if (slot !== undefined) { s.cacheHits++; cref[slot] = 1; } else { s.misses++; slot = cacheFill(lpa); }
    return cdv.getUint32(slot * PAGE + inpg, true);
  }
  function store(addr, v) {
    const lpa = Math.floor(addr / PAGE), inpg = addr - lpa * PAGE, off = inpg >> 6, w = inpg & 63;
    let ls = logFind(act, lpa, off);
    if (ls === undefined) {
      if (act.n === m.logLines) { compact(frz); const t = frz; frz = act; act = t; } // swap halves; the full half waits for the next swap
      ls = act.n++; let l2 = act.idx.get(lpa); if (!l2) act.idx.set(lpa, l2 = new Map()); l2.set(off, ls);
      // the CPU stores whole cachelines: take the line's current bytes (the preceding load cached the page)
      const fl = logFind(frz, lpa, off), slot = cmap.get(lpa);
      if (fl !== undefined) act.data.set(frz.data.subarray(fl * LINE, fl * LINE + LINE), ls * LINE);
      else { const sl = slot !== undefined ? slot : cacheFill(lpa); act.data.set(cbuf.subarray(sl * PAGE + off * LINE, sl * PAGE + off * LINE + LINE), ls * LINE); }
    }
    new DataView(act.data.buffer).setUint32(ls * LINE + w, v, true);
    const slot = cmap.get(lpa); if (slot !== undefined) cdv.setUint32(slot * PAGE + inpg, v, true);
  }
  // ---- BAR-style: uncached, straight to the file ----
  const w4 = new Uint8Array(4), w4v = new DataView(w4.buffer);
  const loadBar = (addr) => { readFull(f, w4, addr); s.devReads++; return w4v.getUint32(0, true); };
  const storeBar = (addr, v) => { w4v.setUint32(0, v, true); writeFull(f, w4, addr); s.devWrites++; };
  const L = cxl ? load : loadBar, S = cxl ? store : storeBar;
  const t0 = now(); let lastTick = t0;
  for (let i = 0; i < m.ops; i++) {
    const u = (r() + 0.5) / 4294967296, widx = Math.min(W - 1, Math.floor(W * Math.pow(u, inv))), addr = widx * 4;
    const v = L(addr); s.loads++; const want = shadow.get(widx) || 0; if (v !== want) s.readErrors++;
    if (r() % 100 < m.storePct) { const nv = T20(v); S(addr, nv); shadow.set(widx, nv); s.stores++; }
    s.ops++;
    if ((i & 4095) === 4095 && now() - lastTick > 200) { lastTick = now(); port.postMessage({ id: m.id, type: 'progress', ops: s.ops }); }
  }
  s.loopMs = now() - t0 - s.compactMs;
  // persist: drain both halves of the log, then make the file durable
  const tp = now(); compact(frz); compact(act); f.flush(); s.persistMs = now() - tp;
  // read back every touched word from the file itself
  const tv = now();
  for (const [widx, want] of shadow) { readFull(f, w4, widx * 4); s.verified++; if (w4v.getUint32(0, true) !== want) s.verifyErrors++; }
  s.verifyMs = now() - tv; s.touched = shadow.size; s.mode = m.mode;
  return s;
}
`;

// ---------- main-thread side ----------
// A tiny request/response layer over a spawned worker ({ post, onMessage, terminate }).
function rpc(w) {
  let next = 1; const pending = new Map();
  w.onMessage((m) => {
    if (m.type === "progress") { const p = pending.get(m.id); if (p && p.onProgress) p.onProgress(m); return; }
    if (m.id === undefined || m.id === null) { const err = new Error(m.message || "worker failed"); for (const p of pending.values()) p.reject(err); pending.clear(); return; }
    const p = pending.get(m.id); if (!p) return; pending.delete(m.id);
    m.type === "error" ? p.reject(new Error(m.message)) : p.resolve(m);
  });
  return {
    call(msg, transfer, onProgress) { const id = next++; return new Promise((resolve, reject) => { pending.set(id, { resolve, reject, onProgress }); w.post({ ...msg, id }, transfer); }); },
    terminate() { for (const p of pending.values()) p.reject(new Error("stopped")); pending.clear(); w.terminate(); },
    get busy() { return pending.size; },
  };
}

export function planCapacity(bytes) {
  // ns1 : ns2 : ns3+reserve = 1 : 6 : 1, ns1 in whole MiB, ns2 in whole frames (2 slots + record each)
  const unit = 2 * FRAME_BYTES + REC_BYTES;
  const ns1 = Math.max(16 * 1048576, Math.floor(bytes / 8 / 1048576) * 1048576);
  const F = Math.max(1, Math.min(MAX_FRAMES, Math.floor((bytes * 6 / 8) / unit)));
  const used = ns1 + F * unit;
  return { capacity: bytes, ns1, F, ns2: F * 2 * FRAME_BYTES, ns3: F * REC_BYTES, reserve: Math.max(0, bytes - used), used };
}

// env: { spawn(src), loc, readSuper(), eraseAll() }  (writeSuper goes through channel 0)
export async function openDrive(env, wasmModule, progs, rule, sup) {
  if (!sup || sup.format !== SSD_FORMAT) throw new Error("no Plume SSD drive here");
  const N = sup.channels, chans = [];
  try {
    for (let c = 0; c < N; c++) {
      const r = rpc(env.spawn(CHANNEL_SRC)); chans.push(r);
      const ans = await r.call({ type: "init", module: wasmModule, loc: env.loc, c, N, F: sup.frames, seed: sup.seed, dens: sup.density,
        s1: sup.steps[0], s2: sup.steps[1], rule, progs: progs.map(plainProg) });
      r.J = ans.J;
    }
    await Promise.all(chans.map((r) => r.call({ type: "flush" })));
  } catch (e) { chans.forEach((r) => r.terminate()); throw e; }
  return new Drive(env, sup, chans, progs, rule, wasmModule);
}
const plainProg = (c) => ({ p: c.p, n: c.n, M: c.M, code: c.code, ninit: c.ninit, nstep: c.nstep, nfinal: c.nfinal, outSlot: c.outSlot });

export async function formatDrive(env, wasmModule, progs, rule, params, onProgress) {
  const { capacity, channels, seed, density, steps, consoleVersion } = params;
  if (!Number.isInteger(channels) || channels < 1 || channels > MAX_CHANNELS) throw new Error(`channels must be 1..${MAX_CHANNELS}`);
  if (!Array.isArray(steps) || steps.some((s) => !Number.isInteger(s) || s < 1 || s > 1000)) throw new Error("steps must be whole numbers from 1 to 1000");
  if (!Number.isInteger(density) || density < 0 || density > 100) throw new Error("density must be 0..100");
  const plan = planCapacity(capacity);
  const sup = { format: SSD_FORMAT, console: consoleVersion, created: new Date().toISOString(), state: "formatting",
    frames: plan.F, channels, seed: seed >>> 0, density, steps, frame_bytes: FRAME_BYTES, ns1_bytes: plan.ns1, capacity_bytes: capacity, roots: {}, paths: {} };
  await env.eraseAll();
  const drive = await openDrive(env, wasmModule, progs, rule, sup);
  return fillFrames(drive, false, params.signal, onProgress);
}
// Finish a format that was stopped or interrupted: frames that already have a record are kept.
export async function resumeFormat(env, wasmModule, progs, rule, sup, signal, onProgress) {
  if (!sup || sup.format !== SSD_FORMAT || sup.state !== "formatting") throw new Error("there is no unfinished format to resume");
  const drive = await openDrive(env, wasmModule, progs, rule, sup);
  return fillFrames(drive, true, signal, onProgress);
}
async function fillFrames(drive, resume, signal, onProgress) {
  const sup = drive.sup, steps = sup.steps;
  try {
    await drive.saveSuper();
    const CH = 8; let done = 0;
    await Promise.all(drive.chans.map(async (r) => {
      for (let j = 0; j < r.J; j += CH) {
        if (drive.stopFlag || (signal && signal.stopped)) throw new Error("format stopped; resume it, or erase the drive");
        await r.call({ type: "format", j0: j, j1: Math.min(r.J, j + CH), resume }, [], (p) => { done += p.n; onProgress && onProgress(done, sup.frames); });
      }
    }));
    const sc = await drive.scan();
    if (sc.bad || sc.lo !== 0 || sc.hi !== 0) throw new Error(`${sc.bad} frames still have no generation-0 record`);
    sup.state = "ready"; sup.roots["0"] = await stackRoot(sup.frames, 0, steps[0], steps[1], sc.digs); sup.paths["0"] = "format";
    await drive.saveSuper();
  } catch (e) { await drive.close(); throw e; }
  return drive;
}

export class Drive {
  constructor(env, sup, chans, progs, rule, wasmModule) { Object.assign(this, { env, sup, chans, progs, rule, wasmModule, stopFlag: false }); }
  get N() { return this.sup.channels; }
  get F() { return this.sup.frames; }
  saveSuper() { return this.chans[0].call({ type: "putText", name: "super.json", text: JSON.stringify(this.sup, null, 1) }); }
  async scan() {
    const F = this.F, N = this.N, gens = new Uint32Array(F), engs = new Uint8Array(F), digs = new Uint8Array(F * 32); let bad = 0;
    const parts = await Promise.all(this.chans.map((r) => r.call({ type: "scan" })));
    parts.forEach((p, c) => { bad += p.bad; for (let j = 0; j < p.gens.length; j++) { const f = j * N + c; gens[f] = p.gens[j]; engs[f] = p.engs[j]; digs.set(p.digs.subarray(j * 32, j * 32 + 32), f * 32); } });
    let lo = Infinity, hi = -Infinity; for (const g of gens) { if (g === 0xffffffff) continue; if (g < lo) lo = g; if (g > hi) hi = g; }
    return { gens, engs, digs, bad, lo, hi };
  }
  stop() { this.stopFlag = true; }
  // Advance every frame from generation g to g+1. mode: "storage" | "host" | "coop".
  // host: { engine, q } ; coop: share of channels given to the host path (0..1).
  async pass({ mode, engine, q = 8, share = 0.5, onEvent, thumbEveryMs = 250 }) {
    this.stopFlag = false;
    const sc = await this.scan();
    if (sc.bad) throw new Error(`${sc.bad} frame records are missing or damaged; format the drive again`);
    if (sc.hi - sc.lo > 1) throw new Error(`frames span generations ${sc.lo}..${sc.hi}; the drive is inconsistent`);
    const g = sc.lo, N = this.N, F = this.F;
    let hostCh = 0;
    if (mode === "host") hostCh = N; else if (mode === "coop") hostCh = Math.max(1, Math.min(N - 1, Math.round(N * share)));
    if ((mode === "host" || mode === "coop") && !engine) throw new Error("the host path needs an engine");
    if (mode === "coop" && N < 2) throw new Error("cooperative mode needs at least 2 channels");
    const todo = this.chans.map(() => []);
    for (let f = 0; f < F; f++) if (sc.gens[f] === g) todo[f % N].push(Math.floor(f / N));
    const total = todo.reduce((a, t) => a + t.length, 0), stats = newStats(total, F - total, g + 1, hostCh, N);
    const emit = (e) => { e.t = now(); onEvent && onEvent(e, stats); };
    let lastThumb = 0;
    const wantThumb = () => { const t = now(); if (t - lastThumb > thumbEveryMs) { lastThumb = t; return true; } return false; };
    const storageLoop = async (c) => {
      const r = this.chans[c], list = todo[c];
      const one = async () => {
        while (list.length && !this.stopFlag) {
          const j = list.shift(), t0 = now();
          const a = await r.call({ type: "compute", j, gen: g, thumb: wantThumb() });
          stats.done++; stats.storage.frames++; stats.storage.ms.read += a.ms.read; stats.storage.ms.check += a.ms.check; stats.storage.ms.xpu += a.ms.xpu;
          stats.storage.ms.write += a.ms.write; stats.storage.ms.hash += a.ms.hash; stats.storage.lat += now() - t0; stats.storage.linkBytes += 160;
          emit({ kind: "frame", path: "storage", c, f: a.f, gen: a.gen, digest: a.digest, thumb: a.thumb });
        }
      };
      await Promise.all([one(), one()]); // two requests in flight keep the worker busy between messages
    };
    const hostLoop = async (chs) => {
      const lists = chs.map((c) => todo[c]); let rr = 0, inflight = 0;
      const nextJob = () => { for (let k = 0; k < lists.length; k++) { const i = (rr + k) % lists.length; if (lists[i].length) { rr = i + 1; return { c: chs[i], j: lists[i].shift() }; } } return null; };
      const engCode = ENGINE_CODES[engine.name] || 2;
      const lane = async () => {
        for (let job = nextJob(); job && !this.stopFlag; job = nextJob()) {
          const r = this.chans[job.c]; inflight++; stats.host.maxInflight = Math.max(stats.host.maxInflight, inflight);
          const t0 = now(); const a = await r.call({ type: "read", j: job.j, gen: g }); const t1 = now(); inflight--;
          stats.host.reads++; stats.host.readLat += t1 - t0; stats.host.ms.read += a.ms.read; stats.host.ms.check += a.ms.check;
          const x0 = now(); const o1 = await engine.run(this.progs[0], a.buf, this.sup.steps[0], this.rule); const o2 = await engine.run(this.progs[1], o1.out, this.sup.steps[1], this.rule); const x1 = now();
          stats.host.ms.xpu += o1.ms + o2.ms; stats.host.ms.engine += x1 - x0; // xpu = engine time; engine = wall time incl. queueing
          const th = wantThumb() ? thumbOf(o2.out) : null;
          const b = await r.call({ type: "write", j: job.j, gen: g + 1, buf: o2.out, eng: engCode }, [o2.out.buffer]);
          stats.host.ms.write += b.ms.write; stats.host.ms.hash += b.ms.hash; stats.host.linkBytes += 2 * FRAME_BYTES;
          stats.done++; stats.host.frames++;
          emit({ kind: "frame", path: "host", c: job.c, f: b.f, gen: b.gen, digest: b.digest, thumb: th });
        }
      };
      await Promise.all(Array.from({ length: Math.max(1, q) }, lane));
    };
    stats.t0 = now();
    const jobs = [];
    if (hostCh) jobs.push(hostLoop(Array.from({ length: hostCh }, (_, i) => i)));
    for (let c = hostCh; c < N; c++) jobs.push(storageLoop(c));
    let failure = null;
    await Promise.all(jobs.map((p) => p.catch((e) => { failure = failure || e; this.stopFlag = true; })));
    await Promise.all(this.chans.map((r) => r.call({ type: "flush" })));
    stats.t1 = now();
    if (failure) throw failure;
    if (stats.done === total) {
      const after = await this.scan();
      if (after.lo !== g + 1 || after.hi !== g + 1) throw new Error(`after the pass frames span generations ${after.lo}..${after.hi}`);
      stats.root = await stackRoot(F, g + 1, this.sup.steps[0], this.sup.steps[1], after.digs);
      const prior = this.sup.roots[String(g + 1)];
      stats.rootMatchesPrior = prior ? prior === stats.root : null;
      this.sup.roots[String(g + 1)] = stats.root; this.sup.paths[String(g + 1)] = describeMix(after.engs);
      await this.saveSuper();
    } else stats.stopped = true;
    return stats;
  }
  // Recompute sample frames from their seed on a host engine and compare with the stored digests.
  async verify({ engine, samples = 4, onEvent }) {
    const sc = await this.scan();
    if (sc.bad) throw new Error(`${sc.bad} frame records are missing or damaged`);
    const F = this.F, picks = new Set([0, F - 1]);
    for (let i = 1; picks.size < Math.min(F, samples); i++) picks.add(Math.floor((i * 0.6180339887 % 1) * F));
    const out = [];
    for (const f of [...picks].sort((a, b) => a - b)) {
      const g = sc.gens[f]; let x = seedField(frameSeed(this.sup.seed, f), this.sup.density); const t0 = now();
      for (let k = 0; k < g; k++) { x = (await engine.run(this.progs[0], x, this.sup.steps[0], this.rule)).out; x = (await engine.run(this.progs[1], x, this.sup.steps[1], this.rule)).out; }
      const d = await frameDigest(f, g, new Uint8Array(x.buffer, x.byteOffset, FRAME_BYTES));
      const stored = sc.digs.subarray(f * 32, f * 32 + 32), ok = hex(d) === hex(stored);
      const row = { f, gen: g, ok, madeBy: ENGINE_NAMES[sc.engs[f]] || "unknown", checkedOn: engine.label, ms: now() - t0, digest: hex(d).slice(0, 16) };
      out.push(row); onEvent && onEvent(row);
    }
    let rootOk = null;
    if (sc.lo === sc.hi && this.sup.roots[String(sc.lo)]) rootOk = (await stackRoot(F, sc.lo, this.sup.steps[0], this.sup.steps[1], sc.digs)) === this.sup.roots[String(sc.lo)];
    return { rows: out, rootOk, gen: sc.lo === sc.hi ? sc.lo : null };
  }
  async close() { for (const r of this.chans) { try { await r.call({ type: "close" }); } catch { /* already gone */ } r.terminate(); } this.chans = []; }
}
const now = () => (globalThis.performance ? performance.now() : Date.now());
function newStats(total, skipped, gen, hostCh, N) {
  const ms = () => ({ read: 0, check: 0, xpu: 0, write: 0, hash: 0, engine: 0 });
  return { total, skipped, gen, hostCh, N, done: 0, t0: 0, t1: 0, root: null,
    storage: { frames: 0, ms: ms(), lat: 0, linkBytes: 0 }, host: { frames: 0, ms: ms(), reads: 0, readLat: 0, maxInflight: 0, linkBytes: 0 } };
}
function describeMix(engs) {
  const n = new Map(); for (const e of engs) n.set(e, (n.get(e) || 0) + 1);
  return [...n].map(([e, k]) => `${ENGINE_NAMES[e] || "?"} ×${k}`).join(", ");
}

// ---------- the RAM controller, main-thread side ----------
export async function openRam(env, bytes) {
  const r = rpc(env.spawn(RAM_SRC)); await r.call({ type: "init", loc: env.loc, bytes });
  return {
    workload: (o, onProgress) => r.call({ type: "workload", ...o }, [], onProgress),
    bench: (o = {}) => r.call({ type: "bench", ...o }),
    async close() { try { await r.call({ type: "close" }); } catch { /* gone */ } r.terminate(); },
    terminate: () => r.terminate(),
  };
}

// ---------- the note's model of a 2 TiB drive (figures from the operator's note) ----------
export const NOTE_MEDIA = [
  { id: "ddr", name: "Server DDR4 / DDR5", latUs: 0.07 },
  { id: "optane", name: "3D XPoint (Optane P5800X)", latUs: 11 },
  { id: "znand", name: "ULL Z-NAND (array read)", latUs: 3 },
  { id: "xlflash", name: "ULL XL-FLASH (array read)", latUs: 4 },
  { id: "slc", name: "Enterprise SLC (array read)", latUs: 25 },
  { id: "tlc", name: "MLC / TLC NAND (array read)", latUs: 50 },
  { id: "tlc-load", name: "TLC 980 Pro under load", latUs: 324 },
];
export const NOTE_NAMESPACES = [
  { ns: "nvme0n1", gib: 256, role: "byte-addressable SSD-RAM (CXL.mem or MGLRU + zswap)" },
  { ns: "nvme0n2", gib: 1536, role: "raw LBA for XPU-initiated access (BaM, GDS)" },
  { ns: "nvme0n3", gib: 256, role: "near-storage KV spill 128 GiB + over-provisioning 128 GiB" },
];
// Little's law: requests in flight needed to sustain bandwidth T at latency L with requests of `size` bytes
export const littleQ = (bytesPerSec, latUs, size) => (bytesPerSec * latUs * 1e-6) / size;
export const ansRatio = (s) => (s + 1) / 2;                 // HILOS: host traffic, baseline / attention-near-storage
export const alphaStar = (bPci, bSsd) => (2 * bPci) / (bSsd + bPci);
