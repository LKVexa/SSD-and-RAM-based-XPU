// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 RUSSELL PHILIP SMITHSON
// Serve web/ on http://127.0.0.1:8789 with cross-origin isolation, so the XPU can use
// SharedArrayBuffer threads. 8789 is already in JA21 Blank Console's local_origins.
// Hardened: loopback only, GET/HEAD only, no path escapes, malformed URLs answer 400.
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('.', import.meta.url)), 'web');
const type = { '.html': 'text/html; charset=utf-8', '.wasm': 'application/wasm', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json' };
const port = Number(process.env.PLUME_PORT || 8789);
const base = {
  'cache-control': 'no-store',
  'cross-origin-opener-policy': 'same-origin',
  'cross-origin-embedder-policy': 'credentialless',
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
};

const server = createServer(async (req, res) => {
  const send = (code, body = '', extra = {}) => { res.writeHead(code, { ...base, 'content-type': 'text/plain; charset=utf-8', ...extra }); res.end(req.method === 'HEAD' ? undefined : body); };
  try {
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(405, 'method not allowed', { allow: 'GET, HEAD' });
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); } catch { return send(400, 'bad request'); }
    if (pathname.includes('\0')) return send(400, 'bad request');
    const file = resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (file !== root && !file.startsWith(root + sep)) return send(403, 'forbidden');
    if (!type[extname(file)]) return send(404, 'not found');
    const info = await stat(file).catch(() => null);
    if (!info || !info.isFile()) return send(404, 'not found');
    const body = await readFile(file);
    res.writeHead(200, { ...base, 'content-type': type[extname(file)], 'content-length': body.length });
    res.end(req.method === 'HEAD' ? undefined : body);
  } catch { if (!res.headersSent) send(500, 'server error'); else res.destroy(); }
});
server.on('clientError', (_e, socket) => socket.destroy());
server.listen(port, '127.0.0.1', () => console.log(`Plume SSD-RAM-XPU Console on http://127.0.0.1:${port}/`));
