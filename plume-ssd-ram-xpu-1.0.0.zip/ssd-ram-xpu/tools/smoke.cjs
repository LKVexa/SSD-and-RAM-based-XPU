// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 RUSSELL PHILIP SMITHSON
// End-to-end smoke test in headless Chromium against the real OPFS: start serve.mjs, format a
// small drive, run an in-storage pass, re-format and run a host pass, run a cooperative pass,
// verify, run the SSD-RAM comparison, and require identical roots and no page errors.
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const path = require('path');
const PORT = 8790;
(async () => {
  const srv = spawn(process.execPath, [path.resolve(__dirname, '../serve.mjs')], { env: { ...process.env, PLUME_PORT: String(PORT) }, stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 600));
  const b = await chromium.launch({ args: ['--enable-unsafe-webgpu', '--enable-features=Vulkan', '--use-vulkan=swiftshader', '--use-webgpu-adapter=swiftshader', '--disable-vulkan-surface'] });
  const p = await b.newPage(); const errs = []; const out = {};
  p.on('pageerror', (e) => errs.push(e.message));
  p.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_TUNNEL|ERR_CONNECTION|ERR_NAME|ERR_CERT|ERR_PROXY/.test(m.text()) && errs.push(m.text()));
  const waitMsg = (id, re, ms = 180000) => p.waitForFunction(([i, r]) => new RegExp(r).test(document.getElementById(i).textContent), [id, re.source], { timeout: ms });
  const text = (id) => p.textContent('#' + id);
  try {
    await p.goto(`http://127.0.0.1:${PORT}/`);
    await p.waitForFunction(() => /disk: OPFS/.test(document.getElementById('pills').textContent), null, { timeout: 60000 });
    out.pills = await text('pills');
    await p.fill('#in-cap', '0.25'); await p.selectOption('#in-ch', '4'); await p.fill('#in-seed', '7');
    const format = async () => { await p.click('#b-format'); await p.click('#b-format'); await waitMsg('fmsg', /formatted in|failed/); out.fmsg = await text('fmsg'); if (!/formatted/.test(out.fmsg)) throw new Error(out.fmsg); };
    // stop a format part-way, then resume it
    await p.click('#b-format'); await p.click('#b-format'); await waitMsg('fmsg', /\d+ \/ \d+ frames/); await p.click('#b-stop');
    await waitMsg('fmsg', /format failed: format stopped/); out.stopped = await text('fmsg');
    await p.click('#b-resume'); await waitMsg('fmsg', /format finished|resume failed/); out.resumed = await text('fmsg');
    await p.click('[data-mode="storage"]'); await p.click('#b-pass'); await waitMsg('pmsg', /generation 1|failed/); out.storage = await text('rmsg'); out.storageLive = await text('little');
    await format();
    await p.click('[data-mode="host"]'); await p.selectOption('#sel-engine', 'wasm-mt'); await p.click('#b-pass'); await waitMsg('pmsg', /generation 1|failed/); out.host = await text('rmsg'); out.hostLive = await text('little');
    await p.click('[data-mode="coop"]'); await p.click('#b-pass'); await waitMsg('pmsg', /generation 2|failed/); out.coop = await text('rmsg');
    await p.fill('#in-samples', '3'); await p.selectOption('#sel-vengine', 'webgpu').catch(() => {}); await p.click('#b-verify'); await waitMsg('vmsg', /identical|failed/, 300000); out.verify = await text('vmsg');
    await p.fill('#in-ops', '100000'); await p.click('#b-ram'); await waitMsg('ram-msg', /correct|ERRORS|failed/); out.ram = await text('ram-msg'); out.ramTable = await p.innerText('#ram-t');
    await p.click('#b-bench'); await waitMsg('ram-msg', /4 KiB|failed/); out.bench = await text('ram-msg');
    out.model = await text('lq-here') + ' | ' + await text('ans-here') + ' | ' + await text('al-here');
    await p.screenshot({ path: path.resolve(__dirname, '../test/out-smoke.png'), fullPage: true });
    // reload: the drive must reopen from disk
    await p.reload(); await p.waitForFunction(() => /opened drive/.test(document.getElementById('log').textContent), null, { timeout: 60000 }); out.reopen = await text('drive');
    await p.click('#b-erase'); await waitMsg('fmsg', /erased|failed/); out.erase = await text('fmsg');
  } catch (e) { errs.push(String(e.message || e)); }
  await b.close(); srv.kill();
  const root1 = (s) => (s || '').match(/root\(1\) ([0-9a-f]{64})/)?.[1];
  const ok = !errs.length && root1(out.storage) && root1(out.storage) === root1(out.host) && /root\(2\)/.test(out.coop) && /^\d+ \/ \d+ frames identical · root re-derived/.test(out.verify) && /every load and read-back correct/.test(out.ram) && /erased/.test(out.erase) && /format finished/.test(out.resumed);
  console.log(JSON.stringify(out, null, 1));
  console.log(`${ok ? 'SMOKE OK' : 'SMOKE FAILED'}${errs.length ? ' | errors: ' + errs.join('; ') : ''}`);
  process.exit(ok ? 0 : 1);
})();
