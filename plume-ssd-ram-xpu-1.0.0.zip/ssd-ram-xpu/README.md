# Plume SSD-RAM-XPU Console 1.0.0

The Plume XPU console turned into an SSD-RAM-XPU: the frame stack lives on this machine's disk,
part of the disk is used as byte-addressable memory, and the XPU runs inside the storage workers.

Start: double-click `Start SSD-RAM-XPU Console.cmd` (Windows) or run `node serve.mjs` and open
http://127.0.0.1:8789/. The single-file build `dist/plume-ssd-ram-xpu.html` also works when served
from any https or localhost origin; Wasm threads need the cross-origin isolation `serve.mjs` provides.

| Note's plane | Here |
|---|---|
| I · SSD-RAM via CXL.mem | `ns1.dat` behind the RAM controller worker: page cache + 64 B write log (CXL-style) vs uncached (BAR-style) |
| II · XPU-direct storage | host path: frames read with Q requests in flight into a host engine (Wasm threads / WebGPU) |
| III · near/in-storage XPU | in-storage path: each channel worker runs xpu.wasm on its own frames |
| IV · offload runtime | flat files at fixed offsets, exact-size frame buffers, range check, verified reads, resumable passes |

A browser cannot reach CXL, BaM or raw NVMe LBAs; those appear only in the model panel, with the
note's figures. Measured "disk" latencies include the OS page cache.

Build: `./build.sh` (clang for wasm32, Python 3, Node, Playwright). Tests: `node test/ssd.test.mjs`
(Node, plain files) and `node tools/smoke.cjs` (Chromium, real OPFS).

Licence: GPL-3.0-only. See LICENSE, COPYRIGHT and NOTICE.
