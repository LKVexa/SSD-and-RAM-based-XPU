// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 RUSSELL PHILIP SMITHSON
// SSD-RAM-XPU runtime tests on Node: the channel and RAM workers run in worker_threads with a
// plain-file backend that has the same interface as OPFS sync access handles.
import { Worker } from 'node:worker_threads';
import { readFileSync, mkdtempSync, rmSync, readdirSync, openSync, writeSync, closeSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { compile, BF1_SOURCE, BF2_SOURCE, referenceRun } from '../src/lcufa.js';
import { createWasm1T, createWasm1TWorker } from '../src/engines.js';
import { formatDrive, resumeFormat, openDrive, openRam, planCapacity, frameSeed, seedField, frameDigest, hex, FRAME_BYTES, T20, littleQ, ansRatio, alphaStar } from '../src/ssd.js';

let pass = 0, failn = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ok  ', m); } else { failn++; console.log('  FAIL', m); } };
const spawn = (src) => { const w = new Worker(src, { eval: true }); const hs = new Set(); w.on('message', (m) => hs.forEach((h) => h(m)));
  w.on('error', (e) => hs.forEach((h) => h({ type: 'error', message: e.message })));
  return { post: (m, tr) => w.postMessage(m, tr), onMessage: (f) => hs.add(f), offMessage: (f) => hs.delete(f), terminate: () => w.terminate() }; };
const envAt = (dir) => ({ spawn, loc: { node: dir },
  readSuper: async () => existsSync(join(dir, 'super.json')) ? JSON.parse(readFileSync(join(dir, 'super.json'), 'utf8')) : null,
  eraseAll: async () => { for (const f of readdirSync(dir)) rmSync(join(dir, f), { force: true }); } });
const wasm = readFileSync(new URL('../web/xpu.wasm', import.meta.url));
const module = await WebAssembly.compile(wasm);
const progs = [compile(BF1_SOURCE), compile(BF2_SOURCE)], rule = { birth: 1 << 3, survive: 12 };
const host1 = await createWasm1T(wasm);
const unit = 2 * FRAME_BYTES + 64;
const capFor = (F) => Math.ceil((F * unit) * 8 / 6) + 1;   // capacity that plans exactly F frames
const base = { seed: 11, density: 35, steps: [2, 1], consoleVersion: 'test' };
const dirs = [];
const fresh = () => { const d = mkdtempSync(join(tmpdir(), 'pssd-')); dirs.push(d); return envAt(d); };

console.log('capacity plan');
{ const p = planCapacity(capFor(10)); ok(p.F === 10, `planCapacity gives 10 frames (${p.F})`);
  const big = planCapacity(2 ** 41); ok(big.ns1 === 2 ** 41 / 8 && big.F === Math.floor(2 ** 41 * 6 / 8 / unit), '2 TiB splits 1 : 6 : 1 like the note'); }

console.log('format and root independence from channel count');
const e3 = fresh(), d3 = await formatDrive(e3, module, progs, rule, { ...base, capacity: capFor(10), channels: 3 });
const e2 = fresh(), d2 = await formatDrive(e2, module, progs, rule, { ...base, capacity: capFor(10), channels: 2 });
ok(d3.sup.roots['0'] === d2.sup.roots['0'], `generation-0 root is the same on 3 and 2 channels (${d3.sup.roots['0'].slice(0, 16)})`);
{ const sc = await d3.scan(); ok(sc.lo === 0 && sc.hi === 0 && sc.bad === 0, 'every frame has a generation-0 record');
  const f = 7, x = seedField(frameSeed(11, f), 35), d = await frameDigest(f, 0, new Uint8Array(x.buffer));
  ok(hex(d) === hex(sc.digs.subarray(f * 32, f * 32 + 32)), 'stored digest of frame 7 equals the digest of its seed field'); }

console.log('in-storage pass vs host pass vs cooperative pass');
const sA = await d3.pass({ mode: 'storage' });
const sB = await d2.pass({ mode: 'host', engine: host1, q: 3 });
ok(sA.done === 10 && sB.done === 10, 'both passes advance all 10 frames');
ok(sA.root === sB.root, `generation-1 root: in-storage on 3 channels = host Wasm on 2 channels (${sA.root.slice(0, 16)})`);
ok(sA.host.linkBytes === 0 && sB.host.linkBytes === 10 * 2 * FRAME_BYTES, 'host-link traffic: 0 bytes in storage, 2 frames per frame on the host path');
const sC = await d3.pass({ mode: 'coop', engine: host1, share: 0.34 });
const sD = await d2.pass({ mode: 'storage' });
ok(sC.root === sD.root && sC.host.frames > 0 && sC.storage.frames > 0, `generation-2 root: cooperative (host ${sC.host.frames} + storage ${sC.storage.frames}) = in-storage`);
ok(d3.sup.roots['2'] === sC.root && JSON.parse(readFileSync(join(e3.loc.node, 'super.json'), 'utf8')).roots['2'] === sC.root, 'super.json records the root');

console.log('reference interpreter agrees with the in-storage XPU');
{ const f = 4; let x = seedField(frameSeed(11, f), 35);
  for (let k = 0; k < 2; k++) { x = referenceRun(progs[0], x, 2); x = referenceRun(progs[1], x, 1); }
  const d = await frameDigest(f, 2, new Uint8Array(x.buffer));
  const sc = await d3.scan(); ok(hex(d) === hex(sc.digs.subarray(f * 32, f * 32 + 32)), 'frame 4 after two passes: JS reference = stored digest'); }

console.log('verify on a host engine');
{ const w1 = await createWasm1TWorker(wasm, spawn); const v = await d3.verify({ engine: w1, samples: 5 });
  ok(v.rows.length === 5 && v.rows.every((r) => r.ok) && v.rootOk === true, `5 sampled frames recomputed from seed match; root re-derived (${v.rows.map((r) => r.f).join(',')})`); }

console.log('stop and resume');
{ const e = fresh(), d = await formatDrive(e, module, progs, rule, { ...base, capacity: capFor(12), channels: 2 });
  let n = 0; const s1 = await d.pass({ mode: 'storage', onEvent: () => { if (++n === 3) d.stop(); } });
  ok(s1.stopped && s1.done >= 3 && s1.done < 12 && !s1.root, `stopped after ${s1.done} of 12 frames`);
  const s2 = await d.pass({ mode: 'host', engine: host1, q: 2 });
  ok(s2.skipped === s1.done && s2.done === 12 - s1.done, 'resume skips the frames already advanced');
  const e4 = fresh(), d4 = await formatDrive(e4, module, progs, rule, { ...base, capacity: capFor(12), channels: 4 }); const s4 = await d4.pass({ mode: 'storage' });
  ok(s2.root === s4.root, 'resumed mixed-path root = uninterrupted root on 4 channels');
  await d.close(); await d4.close();
  // reopen from super.json
  const sup = await e.readSuper(); const r = await openDrive(e, module, progs, rule, sup); const sc = await r.scan();
  ok(sup.state === 'ready' && sc.lo === 1 && sc.hi === 1, 'a reopened drive reads its records back'); await r.close(); }

console.log('stopped format resumes');
{ const e = fresh(), sig = { stopped: false }; let err = '';
  try { await formatDrive(e, module, progs, rule, { ...base, capacity: capFor(200), channels: 2, signal: sig }, (d) => { if (d >= 40) sig.stopped = true; }); } catch (x) { err = x.message; }
  const sup = await e.readSuper(); ok(/format stopped/.test(err) && sup.state === 'formatting', 'a stopped format leaves an unfinished drive');
  let seen = 0; const d = await resumeFormat(e, module, progs, rule, sup, null, (n) => { seen = n; });
  const e2b = fresh(), full = await formatDrive(e2b, module, progs, rule, { ...base, capacity: capFor(200), channels: 3 });
  ok(seen === 200 && d.sup.state === 'ready' && d.sup.roots['0'] === full.sup.roots['0'], 'resumed format finishes with the same root as an uninterrupted one');
  await d.close(); await full.close(); }

console.log('tamper detection');
{ await d2.close(); const p = join(e2.loc.node, 'ch01.dat'); const fd = openSync(p, 'r+'); writeSync(fd, Buffer.from([0xff]), 0, 1, 2 * FRAME_BYTES * 0 + 0 + 100); closeSync(fd);
  // frame 1 lives in channel 1, local 0, generation 2 → slot 0
  const r = await openDrive(e2, module, progs, rule, await e2.readSuper());
  let err = ''; try { await r.pass({ mode: 'storage' }); } catch (x) { err = x.message; }
  ok(/does not match its stored digest/.test(err), `a flipped byte is refused on read: ${err}`); await r.close(); }

console.log('frame range check on host writes');
{ const e = fresh(), d = await formatDrive(e, module, progs, rule, { ...base, capacity: capFor(2), channels: 1 });
  const bad = { name: 'wasm-1t', label: 'bad', run: async (c, x) => { const o = Uint32Array.from(x); o[5] = 1 << 22; return { out: o, ms: 0 }; } };
  let err = ''; try { await d.pass({ mode: 'host', engine: bad, q: 1 }); } catch (x) { err = x.message; }
  ok(/bits above bit 19/.test(err), 'a host write with a 23-bit word is refused'); const sc = await d.scan(); ok(sc.lo === 0 && sc.hi === 0, 'and nothing was advanced'); await d.close(); }

console.log('SSD-RAM controller');
{ const e = fresh(); const ram = await openRam(e, 64 * 1048576);
  const common = { ops: 60000, storePct: 50, seed: 5, cachePages: 512, logLines: 4096 };
  const hot = await ram.workload({ ...common, alpha: 0.02, mode: 'cxl' });
  ok(hot.readErrors === 0 && hot.verifyErrors === 0 && hot.verified === hot.touched, `CXL-style, high locality: ${hot.ops} ops, every load and ${hot.verified} read-backs correct`);
  ok(hot.stores / Math.max(1, hot.pagesWritten) > 5, `write log coalesces: ${hot.stores} stores → ${hot.pagesWritten} page writes`);
  ok(hot.logHits + hot.cacheHits > hot.misses * 5, `hits ${hot.logHits + hot.cacheHits} vs misses ${hot.misses}`);
  const uni = await ram.workload({ ...common, alpha: 1, mode: 'cxl' });
  ok(uni.readErrors === 0 && uni.verifyErrors === 0 && uni.compactions > 0, `CXL-style, uniform: correct through ${uni.compactions} compactions`);
  const bar = await ram.workload({ ...common, alpha: 0.02, mode: 'bar' });
  ok(bar.readErrors === 0 && bar.verifyErrors === 0 && bar.devWrites === bar.stores, 'BAR-style: correct, one device write per store');
  const b = await ram.bench({ n: 256 }); ok(b.page4kUs > 0 && b.line64Us > 0, `bench: 4 KiB ${b.page4kUs.toFixed(1)} µs, 64 B ${b.line64Us.toFixed(1)} µs`);
  await ram.close(); }

console.log('the note’s model');
ok(Math.round(littleQ(16e9, 3, 64)) === 750, 'Little’s law: 16 GB/s × 3 µs / 64 B = 750');
ok(Math.round(littleQ(32e9, 0.07, 64)) === 35, 'Little’s law: 32 GB/s × 70 ns / 64 B = 35');
ok(ansRatio(32768) === 16384.5 && alphaStar(1, 3) === 0.5, 'ANS ratio (s+1)/2 and α* = 2B_PCI/(B_SSD+B_PCI)');
ok(T20(0) === 5 && T20(1048575) === (1048575 + (1 | 5)) % 1048576, 'T-function on Z/2^20');

await d3.close();
for (const d of dirs) rmSync(d, { recursive: true, force: true });
console.log(`\n${pass} passed, ${failn} failed`);
process.exit(failn ? 1 : 0);
